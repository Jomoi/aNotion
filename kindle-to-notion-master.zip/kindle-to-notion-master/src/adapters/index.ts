export { NotionAdapter } from "./notion";
